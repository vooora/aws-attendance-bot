import openai
import os

openai.api_key = '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'

def generate_sql_query(prompt):
    return call_llm(prompt)

def generate_response(prompt):
    return call_llm(prompt)

def call_llm(prompt):
    res = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return res['choices'][0]['message']['content'].strip()
