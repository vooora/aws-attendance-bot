from llm_handler import generate_sql_query, generate_response
from sql_executor import run_query
import os

def lambda_handler(event, context):
    user_question = event['sessionState']['intent']['slots']['UserQuestion']['value']['originalValue']

    schema = open('schema.md', 'r').read()

    prompt = f"""
Database schema:
{schema}

User asked:
"{user_question}"

Write an SQL query to answer it.
Just return the query.
"""

    sql_query = generate_sql_query(prompt)

    try:
        data = run_query(sql_query)
    except Exception as e:
        return format_response(f"Error while querying: {str(e)}")

    response_prompt = f"User asked: {user_question}\nData: {data}\nRespond in clear English."
    final_response = generate_response(response_prompt)

    return format_response(final_response)

def format_response(message):
    return {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },
            "intent": {
                "name": "ExamAttendanceQuery",
                "state": "Fulfilled"
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": message
            }
        ]
    }
