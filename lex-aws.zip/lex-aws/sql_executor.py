import pymysql

def run_query(sql):
    DB_HOST = 'attendance-db.c7oe4k42eh8z.eu-north-1.rds.amazonaws.com'
    DB_USER = 'admin'
    DB_PASS = 'ccgroup11'
    DB_NAME = 'attendance-db'

    conn = pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )

    with conn:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            result = cursor.fetchall()

    return result
